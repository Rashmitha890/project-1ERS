package com.ers.service;

import com.ers.model.LoginCredentials;

public interface LoginCredentialsService {
	public boolean addLoginCredentials(LoginCredentials loginCredentials);
}
