package com.ers.dao;

import com.ers.model.LoginCredentials;
import com.ers.model.Signup;

public interface LoginCredentialsDAO {
	public boolean addLoginCredentials(LoginCredentials loginCredentials);
}
